 class Employee
{
    private String name;
    private String address;
    private int id;

public  Employee(String name,String address,int id)
{
    System.out.println("Constracting an employee");
this.name=name;
this.address=address;
this.id=id;
}
public double computepay()
{
System.out.println("inside employee computepay");
return 0.0;
}
public void mailcheck()
{
    System.out.println("mailing check to"  +this.name+" "+   this.address );

}
public String toString()
{
    return name+" " +address +" "+id;
}

public String  getName()
{
return name;
}
public String getaddress()
{
    return address;
}
public void setAddress(String newAddress)
{
address=newAddress;
}
public int id()
{
    return id;
}
public static void main(String args[])
{
    Employee e=new Employee("rana","malda",1);
    e.mailcheck();
}
}