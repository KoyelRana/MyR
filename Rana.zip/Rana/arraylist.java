import java.util.*;
class ram
{
    public static void main(String args[])
    {
        ArrayList a=new ArrayList();
        System.out.println("befor value insert the array size:"+a.size());
        a.add("A");
        a.add("S");
        a.add("d");
        a.add("4");
        a.add(1,"o");
        System.out.println("after insert:"+a.size());
        System.out.println("the values are:"+a);
        a.remove("o");
        a.remove(2);
 System.out.println("after delete:"+a.size());
        System.out.println("after delete:"+a);
    }
}