abstract class Bike

{
   abstract void run();
}
class honda extends Bike
{
    void run()
    {
        System.out.println("run");
    }
     public static void main(String args[]) 
     {
     Bike ob=new honda();
     ob.run();   
    }
}