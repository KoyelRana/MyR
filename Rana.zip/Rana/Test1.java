import java.io.*;
public class Test1
{
public static void main(String args[])
{
    String fileName="temp.txt";
    String line=null;
    
    try {
        FileReader f=new FileReader(fileName);
        BufferedReader b=new BufferedReader(f);
        while((line = b.readLine()) != null) {
                System.out.println(line);
        }
                b.close();
    } catch (FileNotFoundException e) {
       System.out.println(
                "Unable to open file '" + 
                fileName + "'");   
    }
    catch(IOException e)
    {
System.out.println(
                "Error reading file '" 
                + fileName + "'");     
    }
}
}