class Rana3
{
static
{
System.out.println("This java program ran without the main method");

}
}
