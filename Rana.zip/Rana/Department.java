class Department
{
    
}