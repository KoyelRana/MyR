import java.util.*;
class crud1
{

 public static void main(String[] args) {
 int size,i;
 Scanner scan = new Scanner(System.in);
 System.out.println("Enter the no. of elements..");
 size=scan.nextInt();
 int array[]= new int[size];
 System.out.println("Enter "+size+" Values");
 for(i=0;i<size;i++)
 {
 array[i] = scan.nextInt();
 }
 System.out.println(Arrays.toString(array));
 System.out.println("Enter the Search Element...");
 int search=scan.nextInt();
 for(i=0;i<size;i++)
 {
 if(search==array[i])
 {
 System.out.println("Element "+array[i]+" Is found in Poition "+i);
 break;
 }
 else if(array[i]==size)
 {
 System.out.println("Element "+search+" Not found ");
 }
 }
 System.out.println("Enter the Delete Element...");
 int delete=scan.nextInt();
 for(i=0;i<size;i++)
 {
 if(delete==array[i])
 {
 break;
 }
 }
 if(i==size)
 {
 System.out.println("Element "+delete+" not found");
 }
 else{
 while(i<size-1)
 {
 array[i]=array[i+1];
 i++;
 }
 size--;
 }
 System.out.println("After Deletion.....");
 for(i=0;i<size;i++)
 {
 System.out.println(array[i]);
 }
 System.out.println("Add the array element...");
 int newupdate = scan.nextInt();
 int temp_array[]= new int[++size];
 for(i=0;i<size;i++)
 {
 if(i==size-1)
 {
 temp_array[i]=newupdate; }
 else
 {
 temp_array[i]=array[i];
 }
 }
 System.out.println("New Array");
 for(i=0;i<size;i++)
 {
 System.out.println(temp_array[i]);
 }
}
}