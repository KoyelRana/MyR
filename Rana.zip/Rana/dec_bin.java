import java.util.*;
class dec_bin
{
    public static void main(String args[])
    {
        int n;double r,temp;
        System.out.println("Enter the decimal number : \n");
        Scanner in = new Scanner(System.in);
        n=in.nextInt();
while (n<0)
    {
       temp= (n%2);
        r=temp;
        System.out.println(" Binary Conversion : "+r);
        n--;
    }
    
}
}