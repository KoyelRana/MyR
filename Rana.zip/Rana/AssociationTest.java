class AssociationTest
{
    public static void main(String args[])
{
    College c= new College("SONA MUTHYAMMAL");
    Student1 s= new Student1(" RANA SURIYAN");
    System.out.println(s.getStudentName()+"\t is a  student of \t"+c.getCollegeName());

}    
}