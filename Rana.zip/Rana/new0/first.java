package new0;
public class first
{
   public void display()
    {
        System.out.println("vvvvv");
    }
 


}