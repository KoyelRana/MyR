class news
{
    public static void main(String args[])
    {
        if(System.out.println("Hello"))
        
    }
}