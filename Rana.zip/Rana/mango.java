abstract class apple
{
   abstract  void callme();
   public void banana()
   {
       System.out.println("this is concrete method");
   }
}
    class mango extends apple
    {
void callme()
{
    System.out.println("call me");
}
public static void main(String args[])
{
    mango m= new mango();
    m.callme();
m.banana();
}
    }
