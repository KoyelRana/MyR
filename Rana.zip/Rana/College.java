class College
{
    String name;
    College (String name)
    {
        this.name=name;
    }
    public String getCollegeName()
    {
         return this.name;
    }

}