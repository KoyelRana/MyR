import java.util.*;
class crud
{
    public static void main(String args[])
    {
        Scanner in= new Scanner(System.in);
        int array[]=new int[10];
        int i;
        
        for( i=0;i<array.length;i++)
        

        {
            System.out.println("Enter the "+(i+1)+" number");
            array[i]=in.nextInt();
        }
        System.out.println("after inserting the array are:"+ Arrays.toString(array));
        Syetem.out.println("enter the delete element");
        int delete=in.nextInt();
        for( i=0;i<array.length;i++)
        {
if(delete==array[i])
{
break;
}
        }
 if(i==array.length)
 {
 System.out.println("Element "+delete+" not found");
 }
 else{
 while(i<array.length-1)
 {
 array[i]=array[i+1];
 i++;
 }
 array.length--;
 }
 System.out.println("After Deletion.....");
 for(i=0;i<array.length;i++)
 {
 System.out.println(array[i]);
 }
        }
    }
