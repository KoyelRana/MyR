public class Main {
  public static void main(String[] args) {
    byte b;
    Byte bObj1 = new Byte("10");
    Byte bObj2 = new Byte("4");

    System.out.println(bObj1);
    System.out.println(bObj2);
  }
}