class ramm
{
    public static void main(String args[])
    {
        company c= new company(1,"rana");
        employ e=new employ(2,"biswa",c);
        System.out.println(c);
        System.out.println(e);
    }
}