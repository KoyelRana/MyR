import java.util.Scanner;

import java.util.*;

public class TenNumbers{

public static void main(String []args){

Scanner in=new Scanner(System.in);

int[] array=new int[10];

int sum=0;

for(int i=0;i<array.length;i++){

System.out.println("Enter the "+(i+1)+" number");

array[i]=in.nextInt();


sum+=array[i];

}
System.out.println("The numbers are:"+Arrays.toString(array));

System.out.println("The sum is:"+ sum);

}

}