package new2;
import new0.first;
class second 
{
public static void main(String args[])
{

first f=new first();
f.display();

}

}
