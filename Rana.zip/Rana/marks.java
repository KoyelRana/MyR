abstract class student
{
    public abstract void staff();
}
public class marks extends student
{
    public void staff()
    {
    System.out.println("india");
}
public static void main(String args[])
{
    student s= new marks();
    s.staff();
}
}