public class Test {
   public void Age() {
      int age=0;
      byte 
      age = age + 7;
      System.out.println("Sumaiya age is : " + age);
   }

   public static void main(String args[]) {
      Test test = new Test();
      test.Age();
   }
}