import java.util.scanner;
class scanner
{
    public static void main(String args[])
    {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter your name");
        String name= sc.next();
        System.out.println("Name:"+name);
        sc.close();
    }
}