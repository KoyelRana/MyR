interface game
{
    String name="watch-dogs";
void dis0();
}
interface category
{
    String cat="RACING";
    void dis();
}

class test33 implements game,category{
public void dis0()
{
    System.out.println("ddd");
}
    public void dis()
     {
         System.out.println(cat);
     }

        public static void main(String args[])
{

test33 t=new test33();
t.dis();
t.dis0();
System.out.println(game.name);


}

}