abstract class x
{
 void game();

 x()
 {
     System.out.println("DDDDDDDDDDD");
 }
}
class t extends x
{ 
 //   x()
   // {
     //   System.out.println("CONSTRUCTOR");
   // }
   public void game()
  {
      System.out.println("123455");
  }
    public static void main(String args[])
    {
t t1=new t();
t1.game();
    }
}