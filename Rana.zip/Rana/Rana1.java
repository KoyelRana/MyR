class Rana1{
     Rana1()
    {
       // System.out.println();
       return;
      
    }
    
    public static void main(String args[])
    {
        Rana1 rana = new Rana1();
        //int k=rana.Rana2();
       // rana.display();
      //System.out.println(k);
    }
}