    abstract class Sample{  
      abstract void eat();  
    }  
    