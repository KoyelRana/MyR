class time
{
    int hr,min,sec;
    public time()
    {
        hr=10;
        min=20;
        sec=30;
    }
    void display()
    {
        System.out.println(hr+"hour"+min+"minitues"+sec+"seconds");
    }
    public static void main(String[] args)
    {
        time ob =new time();
        ob.display();
    }
}