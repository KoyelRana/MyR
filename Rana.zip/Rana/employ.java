class employ
{
    int id;
    String name;
    company ob;
    employ(int id,String name,company ob)
    {
        this.id=id;
        this.name=name;
        this.ob=ob;
    }
    public String toString()
    {
        return id+" "+ name+" "+ ob;
    }
}