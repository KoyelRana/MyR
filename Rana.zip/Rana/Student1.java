class Student1
{
    String name; 
  Student1(String name)
  {
      this.name=name;
  }
  public String getStudentName()
  {
      return this.name;
  }

}