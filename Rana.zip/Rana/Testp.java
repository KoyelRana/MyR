class Testp{  
     public static void main(String args[]){  
      Sample p=new Sample(){  
      void eat(){System.out.println("nice fruits");}  
      };  
      p.eat();  
     }  
    }  