class rangecal
{
public static void main(String args[])
{
int a= 2147483647;
int b=2147483647;
String c=a+""+b;
int d=Integer.parseInt(c);
System.out.println(d);
}
}