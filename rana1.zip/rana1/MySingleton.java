public class MySingleton
{
    private static MySingleton obj;
    private MySingleton()
    {

    }
    public static MySingleton getInstance()
    {
        if(obj==null)
        {
            obj=new MySingleton();
        }
        return obj;
    }
    public void getSomething()
    {
        System.out.println("hi");
    }
    public static void main(String args[])
    {
        MySingleton s=MySingleton.getInstance();
        s.getSomething();
    }
}