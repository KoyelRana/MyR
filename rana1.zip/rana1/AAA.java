class AAA
{
    int i;
    AAA(int i)
    {
        this.i=i;
    }
   
    public static void main(String args[])
    {
        AAA ob= new AAA(10);
        System.out.println(10);
    }
}