public class ConstructorTest
{
    String name;
    int salary;
    public ConstructorTest(String name)//i craete here constructor
    {
     name=name;
        
    }
    public void setSalary(int Salary)//here i set the value
    {
        salary=Salary;
    }
     public void display()
    {
        System.out.println("the name is"+name);
         System.out.println("the salary is"+salary);
    }

    public static void main(String args[])
    {
        ConstructorTest con=new ConstructorTest("koyel");
        con.setSalary(1000);
        con.display();

    }
}