public class Sample
{
    public static void main(String args[])
    {
        print(1L,Float.valueOf(1));
    }
    public static void print(long value1,double value2)
    {
        System.out.println("long int");
    }
    public static void print(long value1,int value2)
    {
        System.out.println("long int");
    }
    public static void print(long value1,Object value2)
    {
        System.out.println("long object");
    }
}