public class Test1
{
    public static void main(String args[])
    {
        int [] myList={1,2,3,4,5};
        int i;
        
for( i=0;i<myList.length;i++)
{
    System.out.println(myList[i]+"");
}
int total=0;
for( i=0;i<myList.length;i++)
{
    total+=myList[i];
}
System.out.println(total);
 double max = myList[0];
for( i=0;i<myList.length;i++)
{
if(myList[i]>max) 
max=myList[i];
}
System.out.println(max);
    }
}