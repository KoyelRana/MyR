public class ain {
 public static void main(String[] argv) {
 int c = 0;
 int e = 99;
 int d = 0;

 //if (c == 1 & e++ < 100)
 //d = 100;
 c=++e;
 System.out.println(c);
 System.out.println(e);

 //System.out.println("e is " + e);
 System.out.println("d is " + d);
 }
}