public class LocalVariable
{
    public static void calc()
    {
        int Sum=0;
        Sum=Sum+10;
        System.out.println("the sum is:"+Sum);
    }
    public static void main(String args[])
    {
        LocalVariable ob=new LocalVariable();
        ob.calc();
    }
}