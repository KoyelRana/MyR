import java.util.*;
import  java.lang.System;
class AA
{
    int val=1;
}
class B extends AA
{
    int val=2;
}
class C extends B
{
    int val=3;
}
public class Test {
    

public static void main(String... args)
{
AA ref=new AA();
System.out.println(ref.val);
ref=new B();
System.out.println(ref.val);
C ob=new C();
System.out.println(ob.val);
}
}