public class MultidimensionalArray
{
    public static void main(String args[])
    {
        int myList[][]={{1,2,3,4},{3,4,5},{5,6,7}};
        for(int i=0;i<3;i++)
        {
        for(int j=0;j<3;j++)
        {
        System.out.println(myList[i][j]+ " ");

    }
        
    System.out.println();
    }
}
}