package com.mycompany.app;
import java.sql.*;



public class DBconnectionTest {

    public static void main(String[] args) {
        Connection conn = DBConnection.getDBConnection();

        try {
         // String query = "SELECT * FROM employe WHERE doj BETWEEN '2017/01/29' AND '2017/03/03'";
    //String query ="Select * from employe order by salary desc limit 3";
    String query ="Select * from employe order by salary >=10000 AND salary<=20000";


            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                System.out.println(resultSet.getString(1)+" "+resultSet.getString(2)+" "+resultSet.getString(3)+" "+resultSet.getString(4)+" "+resultSet.getString(5)+" "+resultSet.getString(6));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
