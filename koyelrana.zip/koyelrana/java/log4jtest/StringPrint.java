import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class StringPrint
{
    public static void main(String[] args) {
     List<String[]> list=new ArrayList<String[]>();
     String[] pnt={"Koyel","Rana","Playboy"};
     list.add(pnt);
     for (String[] con : list) {
         System.out.println(Arrays.toString(con));
     }
    }
}