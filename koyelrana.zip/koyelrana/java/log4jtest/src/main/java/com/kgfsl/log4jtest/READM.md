# Java 8 Features
# Stream Min 

***Description***

    Stream.min() - Returns the minimum element of this stream according to the provided Comparator.

    Stream.max() - Returns the maximum element of this stream according to the provided Comparator.

***Syntax***

    Stream.min() - Optional<T> min(Comparator<? super T> comparator);
     
    



`import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
List<String> list = Arrays.asList("Gza","Gzb","Gox","Elephant");
String max = list.stream().maComparator.comparing(String::valueOf)).get();
System.out.println("Max:"+ max);
String min = list.stream().min(Comparator.comparing(String::valueOf)).get();
System.out.println("Min:"+ min);
`



***Syntax***

  Stream.max() -   Optional<T> max(Comparator<? super T> comparator);

    
`import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
public class StreamMax {
	public static void main(String[] args) {
		List<String> list = Arrays.asList("G","B","F","E");
		String max = list.stream().max(Comparator.comparing(String::valueOf)).get();
		System.out.println("Max:"+ max);
    }
}`



