package com.kgfsl.log4jtest;
 import java.util.*;
 import java.util.List;
 import java.util.ArrayList;
   import java.util.Arrays; 
   import java.util.stream.Collectors;
 public class Main_Class{
 public static void main(String args[]){
 List<Parent_Class> persons =new ArraysList(
        new Parent_Class("John", new Sub_Class(Arrays.asList(new Child_Class("Lisa")))),
        new Parent_Class("Clara", new  Sub_Class(Arrays.asList(new Child_Class("Lisa")))),
        new Parent_Class("George", new  Sub_Class(Arrays.asList(new Child_Class("Paul")))));

    Map<String,List<Parent_Class>> map =
        persons.stream()
               .flatMap(p -> p.sub_Class.children.stream().map(c -> new AbstractMap.SimpleEntry<>(c,p)))
               .collect(Collectors.groupingBy(
                 e -> e.getKey().log4jtest,
                 Collectors.mapping(Map.Entry::getValue, Collectors.toList())
               ));

    System.out.println(map);
 }
 }