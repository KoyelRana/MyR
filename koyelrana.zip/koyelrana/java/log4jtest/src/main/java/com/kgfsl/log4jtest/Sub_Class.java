package com.kgfsl.log4jtest;
import java.util.*;

public class Sub_Class
{
    List<Child_Class> children;

}