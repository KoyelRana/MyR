package com.kgfsl.log4jtest;

public class Child_Class
{
    String log4jtest;
    //String log4jtest2;
}