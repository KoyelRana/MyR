package com.kgfsl.log4jtest;
import java. util.*;
import java.util.stream.Collectors;  
class Product
{
    int id;
    String name;
    float price;
    public Product(int id,String name,float price)
    {
        this.id=id;
        this.name=name;
        this.price=price;
    }
    public static void main(String args[])
    {
        List<Product>productList=new ArrayList<Product>();
        productList.add(new Product(1,"x",2000));
        productList.add(new Product(2,"c",1000));
        productList.add(new Product(3,"y",4000));
        productList.add(new Product(4,"r",3000));
        productList.add(new Product(5,"a",5000));
        List<Float>ProductpriceList=productList.stream()
        .filter(p -> p.price >= 3000 && p.price<=5000).map(p->p.price) .collect(Collectors.toList());
     System.out.println(ProductpriceList);
    }
}